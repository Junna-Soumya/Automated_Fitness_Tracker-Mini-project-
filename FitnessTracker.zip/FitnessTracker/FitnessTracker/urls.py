"""FitnessTracker URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from fitness_app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index/', views.index),
    path('/', views.index),
    path('admin_login/', views.admin_login, name='admin_login'),
    path('admin_login_validate/', views.admin_login_validate),
    path('admin_home/', views.admin_home),
    path('add_food_item/', views.add_food_item),
    path('add_food_item_code/', views.add_food_item_code),
    path('show_food_items/', views.show_food_items, name='show_food_items'),
    path('delete_food_item/<int:foodId>/', views.delete_food_item, name='delete_food_item'),
    path('add_workout/', views.add_workout),
    path('add_workout_code/', views.add_workout_code),
    path('show_workouts/', views.show_workouts, name='show_workouts'),
    path('delete_workout/<int:workoutId>/', views.delete_workout, name='delete_workout'),
    path('user_login/', views.user_login, name='user_login'),
    path('user_login_validate/', views.user_login_validate),
    path('user_registration/', views.user_registration),
    path('user_registration_code/', views.user_registration_code),
    path('user_home/', views.user_home),
    path('user_workout/', views.user_workout),
    path('get_food_item/<int:foodId>/', views.get_food_item, name='get_food_item'),
    path('get_food_item1/<str:foodName>/', views.get_food_item1, name='get_food_item1'),
    path('workouts_table/', views.workouts_table, name='workouts_table'),
    path('user_food_history/', views.user_food_history, name='user_food_history'),
    path('show_user_list/', views.show_user_list, name='show_user_list'),
    path('logout/', views.logout),
    path('autocomplete/', views.autocomplete_fooditem, name='autocomplete_fooditem'),
    
]
