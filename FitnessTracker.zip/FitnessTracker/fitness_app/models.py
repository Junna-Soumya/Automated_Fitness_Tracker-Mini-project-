from django.db import models

# Create your models here.
class Admin(models.Model):
    username = models.CharField(max_length=40,primary_key=True)
    password = models.CharField(max_length=40)

class User(models.Model):
    userId = models.AutoField(primary_key=True)
    name = models.CharField(max_length=60)
    email = models.CharField(max_length=60,unique=True)
    mobile = models.CharField(max_length=15)
    password = models.CharField(max_length=20)
    createdDate = models.DateField(auto_now_add=True)

class FoodItems(models.Model):
    foodId = models.AutoField(primary_key=True)
    foodItem = models.CharField(max_length=100)
    protein = models.FloatField()
    cholesterol = models.FloatField()
    carbohydrates = models.FloatField()
    fats = models.FloatField()
    calories = models.FloatField()

class Workouts(models.Model):
    workoutId = models.AutoField(primary_key=True)
    workoutName = models.CharField(max_length=60)
    duration = models.FloatField()
    calories_burned = models.FloatField()


class UserFoodHistory(models.Model):
    historyId = models.AutoField(primary_key=True)
    userId = models.CharField(max_length=60)
    foodItem = models.CharField(max_length=100)
    consumedInGrams = models.FloatField()
    calories = models.FloatField()
    consumedDate = models.DateField(auto_now_add=True)