from collections import defaultdict
import json
from django.http import JsonResponse
from django.shortcuts import render, redirect
from fitness_app.models import  Admin, User, FoodItems, Workouts, UserFoodHistory
from django.contrib import messages
# from rental_app.functions import handle_uploaded_file
from django.utils import timezone
# Create your views here.
def index(request):
     return render(request, "index.html", {})

def admin_login(request):
    return render(request, 'admin_login.html')

def admin_login_validate(request):
    if request.method == "POST":
        try:
          admin=Admin.objects.get(username=request.POST.get("username"))
          if admin.password == request.POST.get("password"):
               return render(request,'admin/admin_home.html')
          else:
                messages.error(request, "Username or password incorrect.")
                return redirect("/admin_login")
        except Exception as e1:
            messages.error(request, "Username or password incorrect.")
            return redirect("/admin_login")


def admin_home(request):
    return render(request,'admin/admin_home.html')

def add_food_item(request):
    return render(request,'admin/add_food_item.html')

def add_food_item_code(request):
    if request.method == 'POST':
        foodItem = request.POST.get('foodItem')
        protein = float(request.POST.get('protein'))
        cholesterol = float(request.POST.get('cholesterol'))
        carbohydrates = float(request.POST.get('carbohydrates'))
        fats = float(request.POST.get('fats'))
        calories = float(request.POST.get('calories'))
        
        
        food = FoodItems.objects.create(foodItem=foodItem, protein=protein, cholesterol=cholesterol, carbohydrates=carbohydrates, fats=fats, calories=calories)
        food.save()
        
        
        messages.error(request, "Food item details added.")
    return render(request, 'admin/add_food_item.html')
    
def show_food_items(request):
    food_items = FoodItems.objects.all()
    return render(request, 'admin/show_food_items.html', {'food_items': food_items})


def delete_food_item(request, foodId):
     food = FoodItems.objects.get(foodId=foodId)
     food.delete()
     messages.error(request, "Food item deleted.")
     return redirect('/show_food_items')

def add_workout(request):
    return render(request,'admin/add_workout.html')

def add_workout_code(request):
    if request.method == 'POST':
        workoutName = request.POST.get('workoutName')
        duration = float(request.POST.get('duration'))
        calories_burned = float(request.POST.get('calories_burned'))
        
        workout = Workouts.objects.create(workoutName=workoutName, duration=duration,calories_burned=calories_burned)
        workout.save()
        
        
        messages.error(request, "Workout detials added.")
    return render(request, 'admin/add_workout.html')

def show_workouts(request):
    workouts = Workouts.objects.all()
    return render(request, 'admin/show_workouts.html', {'workouts': workouts})

def delete_workout(request, workoutId):
    workout = Workouts.objects.get(workoutId=workoutId)
    workout.delete()
    messages.error(request, "Workout deleted.")
    return redirect('/show_workouts')

def user_login(request):
    return render(request,'user_login.html')

def user_home(request):
    return render(request,'users/user_home.html')

def user_registration(request):
    return render(request,'user_registration.html')


def user_registration_code(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        mobile =request.POST.get('mobile')
        password = request.POST.get('password')
        
        userob = User.objects.create(name=name, email=email, mobile=mobile, password=password)
        userob.save()
        
        messages.error(request, "Registration success.")
    return render(request, 'user_login.html')

def user_login_validate(request):
    if request.method == "POST":
        try:
          userob=User.objects.get(email=request.POST.get("email"))
          if userob.password == request.POST.get("password"):
               request.session['userId'] = userob.userId
               return render(request,'users/user_home.html')
          else:
                messages.error(request, "Username or password incorrect.")
                return redirect("/user_login")
        except Exception as e1:
            messages.error(request, "Username or password incorrect.")
            return redirect("/user_login")

def user_workout(request):
    food_items = FoodItems.objects.all().order_by('foodItem')
    return render(request, 'users/user_workout.html', {'food_items': food_items})

def get_food_item(request, foodId):
    food_item = FoodItems.objects.get(foodId=foodId)
    data = {
        'foodItem': food_item.foodItem,
        'protein': food_item.protein,
        'cholesterol': food_item.cholesterol,
        'carbohydrates': food_item.carbohydrates,
        'fats': food_item.fats,
        'calories': food_item.calories,
    }
    return JsonResponse(data)

def get_food_item1(request, foodName):
    food_item = FoodItems.objects.get(foodItem=foodName)
    print('food_item=', food_item)
    data = {
        'foodItem': food_item.foodItem,
        'protein': food_item.protein,
        'cholesterol': food_item.cholesterol,
        'carbohydrates': food_item.carbohydrates,
        'fats': food_item.fats,
        'calories': food_item.calories,
    }
    return JsonResponse(data)

def workouts_table(request):
    if request.method == 'POST':
        txt_total_calories = float(request.POST.get('txt_total_calories'))
        
        
        food_data =eval(request.POST.get('foodData'))
        
        userId=request.session['userId']
        
        food_item_totals = defaultdict(lambda: {'consumed_grams': 0, 'calories': 0})

        
        for data in food_data:
            
            food_item = data['foodItem']
            consumed_grams = float(data.get('consumedInGrams', 100))  
            calories = float(data['calories'])

            food_item_totals[food_item]['consumed_grams'] += consumed_grams
            food_item_totals[food_item]['calories'] += calories

        
        for food_item, totals in food_item_totals.items():
            consumed_grams = totals['consumed_grams']
            calories = totals['calories']
            # add record
            new_entry = UserFoodHistory(userId=userId,
                                        foodItem=food_item,
                                        consumedInGrams=consumed_grams,
                                        calories=calories)
            new_entry.save()


        
        #workouts = Workouts.objects.all()
        ######
        
        workouts = Workouts.objects.order_by('calories_burned')  
        accumulated_workouts = []
        accumulated_calories = 0

        for workout in workouts:
            if accumulated_calories + workout.calories_burned <= txt_total_calories:
                accumulated_workouts.append(workout)
                accumulated_calories += workout.calories_burned
            else:
                break

        return render(request, 'users/workouts_table.html', {'workouts': accumulated_workouts, 'total_calories_to_burn': txt_total_calories})


        ########




        return render(request, 'users/workouts_table.html', {'workouts': workouts,'txt_total_calories':txt_total_calories})

def user_food_history(request):
    userId=request.session['userId']
    food_history = UserFoodHistory.objects.filter(userId=userId).order_by('-consumedDate')
    
    context = {
        'food_history': food_history,
        'user_id': userId,
    }
    return render(request, 'users/user_food_history.html', context)

def show_user_list(request):
    users = User.objects.all()
    return render(request, 'admin/show_users.html', {'users': users})

def logout(request):
    return render(request, "index.html", {})

def autocomplete_fooditem(request):
    #print("ok...")
    if 'term' in request.GET:
        qs = FoodItems.objects.filter(foodItem__icontains=request.GET.get('term')).order_by('foodItem')
        names = list()
        for fooditem in qs:
            names.append(fooditem.foodItem)
        return JsonResponse(names, safe=False)
    return JsonResponse([], safe=False)